package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import pages.LoginPage;
import utilities.Base;

public class LoginSteps extends Base {
    WebDriver driver;
    LoginPage loginPage;

    @Given("User is on the SauceDemo login page")
    public void user_is_on_login_page() {
        // If Base class has launchChrome(), use that instead of new ChromeDriver()
        driver = launchChrome(); // Assuming Base.launchChrome() returns WebDriver
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPage(driver);
    }

    @When("User enters valid username and password")
    public void user_enters_valid_credentials() {
        loginPage.enterUsername("standard_user");
        loginPage.enterPassword("secret_sauce");
    }

    @And("User clicks on the Login button")
    public void user_clicks_login_button() {
        loginPage.clickLogin();
    }

    @Then("User should be redirected to the Products page")
    public void user_should_be_redirected_to_products_page() {
        String actualText = loginPage.getProductsText();
        Assert.assertEquals(actualText, "Products", "Products page verification failed!");
        System.out.println("✅ Login Successful - Verified Products page");
        driver.quit();
    }
}