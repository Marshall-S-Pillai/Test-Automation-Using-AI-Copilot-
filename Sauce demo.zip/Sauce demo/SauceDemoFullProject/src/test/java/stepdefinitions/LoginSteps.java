package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.LoginPage;
import utilities.Base;

import java.time.Duration;

public class LoginSteps extends Base {

    WebDriver driver;
    LoginPage login;
    WebDriverWait wait;

    @Given("User launches {string} browser and opens login page")
    public void user_launches_browser_and_opens_login_page(String browser) {
        if (browser.equalsIgnoreCase("chrome")) {
            launchChrome();
        } else if (browser.equalsIgnoreCase("edge")) {
            launchEdge();
        } else {
            throw new RuntimeException("Unsupported browser: " + browser);
        }
        driver = Base.driver;
        driver.get("https://www.saucedemo.com/");
        login = new LoginPage(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @When("User enters valid username {string} and password {string}")
    public void user_enters_valid_credentials(String username, String password) {
        login.enterUsername(username);
        login.enterPassword(password);
    }

    @And("User clicks login button")
    public void user_clicks_login_button() {
        login.clickLogin();
    }

    @Then("User should be on products page")
    public void user_should_be_on_products_page() {
        String actualText = login.products_page();
        if (!actualText.equals("Products")) {
            throw new AssertionError("Login failed. Expected 'Products' but got: " + actualText);
        }
        System.out.println("Login successful. Products page verified.");
        closeBrowser();
    }
}