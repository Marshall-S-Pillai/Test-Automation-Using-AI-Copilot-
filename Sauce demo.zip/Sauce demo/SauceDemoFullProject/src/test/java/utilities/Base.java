package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Base {
    public static WebDriver driver;

  
    public WebDriver launchChrome() {
        try {
            System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.get("https://www.saucedemo.com/");
            System.out.println("Chrome launched successfully.");
        } catch (Exception e) {
            System.out.println("Failed to launch Chrome: " + e.getMessage());
        }
        return driver;
    }

    
    public WebDriver launchEdge() {
        try {
            System.setProperty("webdriver.edge.driver", "edgedriver_v141.exe");
            driver = new EdgeDriver();
            driver.manage().window().maximize();
            driver.get("https://www.saucedemo.com/");
            System.out.println("Edge launched successfully.");
        } catch (Exception e) {
            System.out.println("Failed to launch Edge: " + e.getMessage());
        }
        return driver;
    }

    
    public void closeBrowser() {
       
            driver.quit();
            System.out.println("Browser closed successfully.");
        
    }
}